#include <cs50.h>
#include <stdio.h>
int main(void)
{
    long long x = get_long("Number on your card\n");
    //To get the card number
    int p = ((x / 10) % 10);
    int q = ((x / 1000) % 10);
    int r = ((x / 100000) % 10);
    int s = ((x / 10000000) % 10);
    int t = ((x / 1000000000) % 10);
    int u = ((x / 100000000000) % 10);
    int v = ((x / 10000000000000) % 10);
    int w = ((x / 1000000000000000) % 10);
    //To get the points that need to be multiplied by 2
    int sum = ((p * 2) % 10) + ((q * 2) % 10) + ((r * 2) % 10) + ((s * 2) % 10) + ((t * 2) % 10) +
              ((u * 2) % 10) + ((v * 2) % 10) + ((w * 2) % 10) + (((p * 2) / 10) % 10) +
              (((q * 2) / 10) % 10) + (((r * 2) / 10) % 10) + (((s * 2) / 10) % 10) +
              (((t * 2) / 10) % 10) + (((u * 2) / 10) % 10) + (((v * 2) / 10) % 10) +
              (((w * 2) / 10) % 10);
    //A code to get the sum of the individual digits
    int rum = ((x) % 10) + ((x / 100) % 10) + ((x / 10000) % 10) + ((x / 1000000) % 10) +
              ((x / 100000000) % 10) + ((x / 10000000000) % 10) + ((x / 1000000000000) % 10) +
              ((x / 100000000000000) % 10);
    //A code to get the sum of the other digits
    int a = (rum + sum);
    //Adding them together then checking if they were modulus of 0
    if (((a % 10) == 0) && ((x / 10000000000) >= 1))
    {
        if ((v == 4 && ((x / 100000000000000) % 10) == 3) ||
            (v == 7 && ((x / 100000000000000) % 10) == 3))
        {
            printf("AMEX\n");
        }
        else if (w == 5 &&
                 (((x / 100000000000000) % 10) == 1 || ((x / 100000000000000) % 10) == 2 ||
                  ((x / 100000000000000) % 10) == 3 || ((x / 100000000000000) % 10) == 4 ||
                  ((x / 100000000000000) % 10) == 5))
        {
            printf("MASTERCARD\n");
        }
        else if ((w == 4) || (((x / 1000000000000) % 10) == 4))
        {
            printf("VISA\n");
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
        printf("INVALID\n");
    //Check if there is a condition it follows to be one of those cards and if not INVALID

}

