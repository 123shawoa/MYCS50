#include "helpers.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#define min(a,b) ((a) < (b) ? (a) : (b))

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{   RGBTRIPLE pixel[height][width];
    //loop through the rows
    for (int h = 0; h< height; h++)
    {
        float x = 0;
        //loop through columns
        for (int w = 0; w< width;w++)
        {
        x = image[h][w].rgbtRed + image[h][w].rgbtBlue + image[h][w].rgbtGreen;
        x = round(x/3);
        image[h][w].rgbtRed = x;
        image[h][w].rgbtBlue = x;
        image[h][w].rgbtGreen = x;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{   //datatype to hold the substitute
    RGBTRIPLE new;
    RGBTRIPLE fake;
    // loop through the rows
    for (int h = 0; h< height; h++)
    {
        int f = 0;
        for (int w = 0; w< width/2;w++)
        {

           new = image[h][w];
           fake = image[h][width-f-1];
           image[h][width-f-1] = new;
           image[h][w] = fake;
           f++;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{    RGBTRIPLE pixel[height][width];
    for (int h = 0; h< height; h++)
    {
        for (int w = 0; w< width;w++)
        {   float x = 0;
            float y = 0;
            float z = 0;

            int f = 0;

           for (int l = h-1; l<=h+1; l++)
           {
            if (l< height && l>= 0)
            {
                for(int d = w-1; d<=w+1;d++)
                {
                    if (d< width && d>= 0 )
                    {
                    x += image[l][d].rgbtRed;
                    y += image[l][d].rgbtBlue;
                    z += image[l][d].rgbtGreen;
                    f++;
                    }
                }
            }
           }

           x =round(x/f);
           y = round(y/f);
           z = round(z/f);
           pixel[h][w].rgbtRed = x;
           pixel[h][w].rgbtBlue = y;
           pixel[h][w].rgbtGreen =z;

        }
    }
    for (int h = 0; h < height; h++)
    {
        for (int w = 0; w < width; w++)
        {
            image[h][w] = pixel[h][w];
        }
        }


    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{ RGBTRIPLE pixel[height][width];
    for (int h = 0; h< height; h++)
    {
        for (int w = 0; w< width;w++)
        {   float x = 0;
            float y = 0;
            float z = 0;
            int g = 1;
            int red = 0;
            int blue = 0;
            int green = 0;
            float u = 0;
            float r = 0;
            float s = 0;

           for (int l = h-1; l<=h+1; l++)
           {int k = 1;

                for(int d = w-1; d<=w+1;d++)
                {
                    if (d< width && d>= 0 && l<height && l>= 0)
                    {
                     RGBTRIPLE new = image[l][d];
                    //apply gx and gy to all pixels (gx)
                     if (g == 3){g = g-2;}
                     int f = (d - w)*g;
                     if (k==3){k = k-2;}
                     int j = (l - h)*k;
                     x += (new.rgbtRed*f);
                     y += (new.rgbtBlue*f);
                     z += (new.rgbtGreen*f);
                     u += (new.rgbtRed*j);
                     r += (new.rgbtBlue*j);
                     s += (new.rgbtGreen*j);
                    }
                    k++;

            }
            g++;
           }
           int newRed = round(min(255, sqrt(x * x + u * u)));
           int newBlue = round(min(255, sqrt(y * y + r * r)));
           int newGreen = round(min(255, sqrt(z * z + s * s)));
           pixel[h][w].rgbtRed = newRed;
           pixel[h][w].rgbtBlue = newBlue;
           pixel[h][w].rgbtGreen = newGreen;
        }
    }
    for (int h = 0; h < height; h++)
    {
        for (int w = 0; w < width; w++)
        {
            image[h][w] = pixel[h][w];
        }
    }
    return;
}
