#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);

int main(void)
{
    // Prompt the user for some text
    string text = get_string("Text: ");

    // Count the number of letters, words, and sentences in the text
    float letters = (float) count_letters(text);
    float words = (float) count_words(text);
    float sentences = (float) count_sentences(text);

    // Compute the Coleman-Liau index
    float L = (float) letters / (words / 100);
    float S = (float) sentences / (words / 100);
    float index = 0.0588 * L - 0.296 * S - 15.8;

    // Print the grade level
    int d = 0;
    d = round(index);

    if (d >= 16)
    {
        printf("Grade 16+\n");
    }
    else if (d < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", d);
    }
}

int count_letters(string text)
{
    // Return the number of letters in text
    int i = 0;
    int x = 0;
    while (text[i] != '\0')
{
    if (isalpha(text[i]))
    {
        x++;
    }
    i++;
}
    return x;
}

int count_words(string text)
{
    // Return the number of words in text
    int i = 0;
    int x = 0;
    while (text[i] != '\0')
    {
        if (isblank(text[i]) || text[i+1] == '\0')
        {
            i++;
            x++;
        }
        else
        {
            i++;
        }
    }
    return (x);
}

int count_sentences(string text)
{
    // Return the number of sentences in text
    int i = 0;
    int x = 0;
    while (text[i] != '\0')
    {
        if ((text[i] == '.' || text[i] == '!' || text[i] == '?') && (isblank(text[i+1]) || text[i+1] == '\0'))
        {
            i++;
            x++;
        }
        else
        {
            i++;
        }
    }
    return x;
}
