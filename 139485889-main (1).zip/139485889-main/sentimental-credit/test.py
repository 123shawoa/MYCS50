from cs50 import get_int
x = get_int("Number: ")
x = str(x)
l = 0
for digit in x:
    l = int(digit) + l
print(l)

