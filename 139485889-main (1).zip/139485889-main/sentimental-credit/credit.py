from cs50 import get_string
def add_up(x):
    x = str(x)
    l = 0
    for digit in x:
        l = int(digit) + l
    return l

def main():
    number = get_string("Number: ")
    number = number.replace("-","")
    if number.isdigit():
        if len(number) == 15 and number[0] == '3' and (number[1] == '4' or number[1] == '7'):
            express(number)
        elif len(number) == 16:
            msvis(number)
        elif len(number) == 13:
            vischeck(number)
        else:
            print("INVALID")
def express(n):
    counter = 2
    counter_2 = 1
    sum1 = int(0)
    sum2 = int(0)
    for d in range(7):
        d = n[len(n)-counter]
        d = int(d)
        d = d*2
        d = add_up(d)
        counter = counter+2
        sum1 = sum1 + d
    for d in range(8):
        d = n[len(n)-counter_2]
        d = int(d)
        counter_2 = counter_2+2
        sum2 = sum2 + d
    totalsum = sum1 + sum2
    if (totalsum%10)==0:
        print ("AMEX")
    else:
        print("INVALID")



def msvis(n):
    if n[0] == '5' and (n[1] in ['1', '2', '3', '4', '5']):
        counter = 2
        counter_2 = 1
        sum1 = int(0)
        sum2 = int(0)
        for d in range(8):
            d = n[len(n)-counter]
            d = int(d)
            d = d*2
            d = add_up(d)
            counter = counter+2
            sum1 = sum1 + d
        for d in range(8):
            d = n[len(n)-counter_2]
            d = int(d)
            counter_2 = counter_2+2
            sum2 = sum2 + d
        totalsum = sum1 + sum2
        if (totalsum%10)==0:
            print ("MASTERCARD")
        else:
            print("INVALID")

    elif n[0] == '4':
        counter = 2
        counter_2 = 1
        sum1 = int(0)
        sum2 = int(0)
        for d in range(8):
            d = n[len(n)-counter]
            d = int(d)
            d = d*2
            d = add_up(d)
            counter = counter+2
            sum1 = sum1 + d
        for d in range(8):
            d = n[len(n)-counter_2]
            d = int(d)
            counter_2 = counter_2+2
            sum2 = sum2 + d
        totalsum = int(sum1 + sum2)
        if (totalsum%10)==0:
            print ("VISA")
        else:
            print("INVALID")
    else:
        print("INVALID")


def vischeck(n):
    if n[0]== '4':
        counter = 2
        counter_2 = 1
        sum1 = int(0)
        sum2 = int(0)
        for d in range(6):
            d = n[len(n)-counter]
            d = int(d)
            d = d*2
            d = add_up(d)
            counter = counter+2
            sum1 = sum1 + d
        for d in range(7):
            d = n[len(n)-counter_2]
            d = int(d)
            counter_2 = counter_2+2
            sum2 = sum2 + d
        totalsum = sum1 + sum2
        if (totalsum%10)==0:
            print ("VISA")
        else:
            print("INVALID")
    else:
        print("INVALID")








main()



