#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // get the string for the player
    string st = get_string("Player 1:");
    string nd = get_string("Player 2:");
    // calculate it
    int i = 0;
    int scores[26] = {1, 3, 3, 2,  1, 4, 2, 4, 1, 8, 5, 1, 3,
                      1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};
    int x = 0;
    int score = 0;
    int y = 0;
    int right = 0;
    int g = 0;
    while (st[i] != '\0')
    {
        if (st[i] >= 'a' && st[i] <= 'z')
        {
            // Assuming 'letter' is a lowercase letter from 'a' to 'z'
            score = scores[st[i] - 'a'];
            x += score;
            i++;
        }
        else if (st[i] >= 'A' && st[i] <= 'Z')
        {
            // Assuming 'letter' is a uppercase letter from 'A' to 'A'
            score = scores[st[i] - 'A'];
            x += score;
            i++;
        }
        else
        {

            printf("\n invalid");
        }
    }
    printf("%i\n", x);
    while (nd[g] != '\0')
    {
        if (nd[g] >= 'a' && nd[g] <= 'z')
        {
            // Assuming 'letter' is a lowercase letter from 'a' to 'z'
            right = scores[nd[g] - 'a'];
            y += right;
            g++;
        }
        else if (nd[g] >= 'A' && nd[g] <= 'Z')
        {
            // Assuming 'letter' is a uppercase letter from 'A' to 'A'
            right = scores[nd[g] - 'A'];
            y += right;
            g++;
        }
        else
        {

            printf("\n invalid");
        }
    }
    // player 1 victory
    printf("%i\n", y);
    if (x > y)
    {
        printf("player 1 wins\n");
    }
    // player 2 victory
    else if (y > x)
    {
        printf("player 2 wins\n");
    }
    // tie
    else
    {
        printf("tie\n");
    }
}
