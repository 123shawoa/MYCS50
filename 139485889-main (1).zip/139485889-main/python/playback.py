word = input()
word = word.replace(" ","...")

print(word)

