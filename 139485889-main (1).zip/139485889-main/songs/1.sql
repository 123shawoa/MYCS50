SELECT name
FROM songs;
