#include <stdio.h>
#include <cs50.h>
int main (void)
{
    int x = get_int("height of pyramid\n");
    while (x<=0 || x>8)
    {x = get_int("height of pyramid\n");}
        for (int z=1; z<=x; z++)
        {
            for (int s =z; s<x; s++)
            {
                printf(" ");
            }

            for (int y = 0; y<z; y++)
            {
                printf("#");
            }
            printf("  ");
            for (int y = 0; y<z; y++)
            {
                printf("#");
            }
            printf ("\n");
        }


}
