def main():
    word = input()
    convert(word)

def convert(word):
    word = word.replace(":)","🙂").replace(":(","🙁")
    print(word)

main()
