#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int j = 0;

int main(int argc, char *argv[])
{
    // Check if the user was cheeky
 if (argc != 2)
    {
        printf("Usage: ./recover FILE\n");
        return 1;
    }
//Open the image needed to be recovered
 FILE *image = fopen(argv[1], "r");
 //Checks if the image failed
 if (image == NULL)
 {
    printf("Could not open file\n");
    return 1;
 }
 uint8_t buffer[512];
 //while there is still data unfinished in the memory card
 FILE *pic = NULL;
 char *filename = malloc(8);
 while (fread(buffer, 1, 512, image) == 512)
 {
    if(buffer[0]==0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3]&0xf0)== 0xe0)
    {
        if(pic != NULL)
        {fclose(pic);}
        sprintf(filename,"%03i.jpg",j++);
        pic = fopen(filename, "w");
        fwrite(buffer,1,512,pic);
        if(pic == NULL)
        {
         return 1;
        }

    }

    else
    {
        if(pic != NULL)
        {
        fwrite(buffer,1,512,pic);
        }

    }
 }

    if (pic != NULL)
    {
        fclose(pic);
    }
    fclose(image);
    free(filename);
    return 0;

 }



