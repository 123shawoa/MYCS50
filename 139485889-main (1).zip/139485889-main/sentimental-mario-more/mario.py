import sys
def get_int(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("Not an integer")
def check(n):
    while n <= 0 or n>8:
        n = get_int("Height of pyramid ")
    return n




def main():
    x = get_int("Height of pyramid ")
    x = check(x)
    for i in range(x):
        print(" " * (x-i-1),end="")
        print("#" * (i+1),end="")
        print("  ",end="")
        print("#" * (i+1))


main()
