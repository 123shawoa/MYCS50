x = (input("What is the answer to the Great Question of Life, the Universe and Everything "))
x = x.strip().lower()
if x == "42" or x == "fortytwo" or x =="forty-two" or x=="forty two":
    print("Yes")
else:
    print("No")

