x = input("What is your name? ")
print(f"hello, {x}")
