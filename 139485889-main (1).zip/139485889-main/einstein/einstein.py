mass = input("m: ")
E = int(mass)*300000000*300000000
print(E)
