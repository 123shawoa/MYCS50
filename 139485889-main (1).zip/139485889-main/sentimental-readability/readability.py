from cs50 import get_string
passage = get_string("Text:")
w = 0
s = 0
l = 0
for c in passage:
    if c == " ":
        w = w + 1
    elif c in ['?', '!', '.']:
        s = s + 1
    elif c.isalnum:
        l = l + 1
w = w + 1
L = round(l/(w/100),0)
S = round(s/(w/100),0)
index = 0.0588 * L - 0.296 * S - 15.8
if index > 1 and index < 16:
    index = int(index)
    print(f"Grade {index}")
elif index<=1:
    print("Before Grade 1")
elif index >=16:
    print("Grade 16+")



